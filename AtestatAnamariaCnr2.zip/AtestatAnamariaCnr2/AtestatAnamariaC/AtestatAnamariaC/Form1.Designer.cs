﻿namespace AtestatAnamariaC
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.menuStrip2 = new System.Windows.Forms.MenuStrip();
            this.homeToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.Home = new System.Windows.Forms.TabPage();
            this.button1 = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.TabCalatorieAstronomica = new System.Windows.Forms.TabPage();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.button6 = new System.Windows.Forms.Button();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.button5 = new System.Windows.Forms.Button();
            this.comboBox2 = new System.Windows.Forms.ComboBox();
            this.label5 = new System.Windows.Forms.Label();
            this.listBox1 = new System.Windows.Forms.ListBox();
            this.button4 = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.comboBox1 = new System.Windows.Forms.ComboBox();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.TabEnciclopedieAstronomica = new System.Windows.Forms.TabPage();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.button9 = new System.Windows.Forms.Button();
            this.button8 = new System.Windows.Forms.Button();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.button17 = new System.Windows.Forms.Button();
            this.button16 = new System.Windows.Forms.Button();
            this.button7 = new System.Windows.Forms.Button();
            this.label6 = new System.Windows.Forms.Label();
            this.TabClasamenteAstronomice = new System.Windows.Forms.TabPage();
            this.listBox2 = new System.Windows.Forms.ListBox();
            this.button15 = new System.Windows.Forms.Button();
            this.button14 = new System.Windows.Forms.Button();
            this.button13 = new System.Windows.Forms.Button();
            this.button12 = new System.Windows.Forms.Button();
            this.button11 = new System.Windows.Forms.Button();
            this.button10 = new System.Windows.Forms.Button();
            this.label7 = new System.Windows.Forms.Label();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.imageList1 = new System.Windows.Forms.ImageList(this.components);
            this.imageList2 = new System.Windows.Forms.ImageList(this.components);
            this.planeteBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.atestatDataSet = new AtestatAnamariaC.atestatDataSet();
            this.constelatiiBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.constelatiiTableAdapter = new AtestatAnamariaC.atestatDataSetTableAdapters.ConstelatiiTableAdapter();
            this.tableAdapterManager = new AtestatAnamariaC.atestatDataSetTableAdapters.TableAdapterManager();
            this.galaxiiTableAdapter = new AtestatAnamariaC.atestatDataSetTableAdapters.GalaxiiTableAdapter();
            this.planeteTableAdapter = new AtestatAnamariaC.atestatDataSetTableAdapters.PlaneteTableAdapter();
            this.steleTableAdapter = new AtestatAnamariaC.atestatDataSetTableAdapters.SteleTableAdapter();
            this.galaxiiBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.steleBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.menuStrip2.SuspendLayout();
            this.tabControl1.SuspendLayout();
            this.Home.SuspendLayout();
            this.TabCalatorieAstronomica.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.TabEnciclopedieAstronomica.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.groupBox1.SuspendLayout();
            this.TabClasamenteAstronomice.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.planeteBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.atestatDataSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.constelatiiBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.galaxiiBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.steleBindingSource)).BeginInit();
            this.SuspendLayout();
            // 
            // menuStrip2
            // 
            this.menuStrip2.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.menuStrip2.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.homeToolStripMenuItem});
            this.menuStrip2.Location = new System.Drawing.Point(0, 0);
            this.menuStrip2.Name = "menuStrip2";
            this.menuStrip2.Size = new System.Drawing.Size(1072, 28);
            this.menuStrip2.TabIndex = 1;
            this.menuStrip2.Text = "menuStrip2";
            this.menuStrip2.ItemClicked += new System.Windows.Forms.ToolStripItemClickedEventHandler(this.menuStrip2_ItemClicked);
            // 
            // homeToolStripMenuItem
            // 
            this.homeToolStripMenuItem.Name = "homeToolStripMenuItem";
            this.homeToolStripMenuItem.Size = new System.Drawing.Size(64, 24);
            this.homeToolStripMenuItem.Text = "Home";
            this.homeToolStripMenuItem.Click += new System.EventHandler(this.homeToolStripMenuItem_Click);
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.Home);
            this.tabControl1.Controls.Add(this.TabCalatorieAstronomica);
            this.tabControl1.Controls.Add(this.TabEnciclopedieAstronomica);
            this.tabControl1.Controls.Add(this.TabClasamenteAstronomice);
            this.tabControl1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tabControl1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tabControl1.Location = new System.Drawing.Point(0, 0);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(1072, 624);
            this.tabControl1.TabIndex = 2;
            // 
            // Home
            // 
            this.Home.BackgroundImage = global::AtestatAnamariaC.Properties.Resources.background;
            this.Home.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.Home.Controls.Add(this.button1);
            this.Home.Controls.Add(this.label2);
            this.Home.Controls.Add(this.label1);
            this.Home.Location = new System.Drawing.Point(4, 31);
            this.Home.Name = "Home";
            this.Home.Padding = new System.Windows.Forms.Padding(3);
            this.Home.Size = new System.Drawing.Size(1064, 589);
            this.Home.TabIndex = 0;
            this.Home.Text = "Home";
            this.Home.UseVisualStyleBackColor = true;
            this.Home.Click += new System.EventHandler(this.Home_Click);
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(389, 254);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(209, 47);
            this.button1.TabIndex = 2;
            this.button1.Text = "Intra in harta cosmica";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Times New Roman", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.label2.Location = new System.Drawing.Point(171, 158);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(659, 33);
            this.label2.TabIndex = 1;
            this.label2.Text = "Alege Galaxia. Urmeaza stelele. Gaseste lumi necunoscute";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Book Antiqua", 22.2F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.SystemColors.ScrollBar;
            this.label1.Location = new System.Drawing.Point(300, 69);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(402, 45);
            this.label1.TabIndex = 0;
            this.label1.Text = "Explorator Astronomic";
            // 
            // TabCalatorieAstronomica
            // 
            this.TabCalatorieAstronomica.BackgroundImage = global::AtestatAnamariaC.Properties.Resources.background2;
            this.TabCalatorieAstronomica.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.TabCalatorieAstronomica.Controls.Add(this.pictureBox1);
            this.TabCalatorieAstronomica.Controls.Add(this.button6);
            this.TabCalatorieAstronomica.Controls.Add(this.textBox1);
            this.TabCalatorieAstronomica.Controls.Add(this.button5);
            this.TabCalatorieAstronomica.Controls.Add(this.comboBox2);
            this.TabCalatorieAstronomica.Controls.Add(this.label5);
            this.TabCalatorieAstronomica.Controls.Add(this.listBox1);
            this.TabCalatorieAstronomica.Controls.Add(this.button4);
            this.TabCalatorieAstronomica.Controls.Add(this.button3);
            this.TabCalatorieAstronomica.Controls.Add(this.button2);
            this.TabCalatorieAstronomica.Controls.Add(this.comboBox1);
            this.TabCalatorieAstronomica.Controls.Add(this.label4);
            this.TabCalatorieAstronomica.Controls.Add(this.label3);
            this.TabCalatorieAstronomica.Location = new System.Drawing.Point(4, 31);
            this.TabCalatorieAstronomica.Name = "TabCalatorieAstronomica";
            this.TabCalatorieAstronomica.Padding = new System.Windows.Forms.Padding(3);
            this.TabCalatorieAstronomica.Size = new System.Drawing.Size(1064, 559);
            this.TabCalatorieAstronomica.TabIndex = 1;
            this.TabCalatorieAstronomica.Text = "Calatorie Astronomica";
            this.TabCalatorieAstronomica.UseVisualStyleBackColor = true;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::AtestatAnamariaC.Properties.Resources.tab2;
            this.pictureBox1.Location = new System.Drawing.Point(685, 279);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(325, 187);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 12;
            this.pictureBox1.TabStop = false;
            // 
            // button6
            // 
            this.button6.Location = new System.Drawing.Point(797, 482);
            this.button6.Name = "button6";
            this.button6.Size = new System.Drawing.Size(245, 53);
            this.button6.TabIndex = 11;
            this.button6.Text = "Enciclopedie Astronomica ----->";
            this.button6.UseVisualStyleBackColor = true;
            this.button6.Click += new System.EventHandler(this.button6_Click);
            // 
            // textBox1
            // 
            this.textBox1.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this.textBox1.Location = new System.Drawing.Point(598, 219);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(199, 28);
            this.textBox1.TabIndex = 10;
            // 
            // button5
            // 
            this.button5.Location = new System.Drawing.Point(598, 158);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(199, 43);
            this.button5.TabIndex = 9;
            this.button5.Text = "Afiseaza constelatia";
            this.button5.UseVisualStyleBackColor = true;
            this.button5.Click += new System.EventHandler(this.button5_Click);
            // 
            // comboBox2
            // 
            this.comboBox2.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this.comboBox2.FormattingEnabled = true;
            this.comboBox2.Items.AddRange(new object[] {
            "Soarele",
            "Sirius A",
            "Alpheratz",
            "Mirach",
            "Dubhe"});
            this.comboBox2.Location = new System.Drawing.Point(598, 108);
            this.comboBox2.Name = "comboBox2";
            this.comboBox2.Size = new System.Drawing.Size(165, 30);
            this.comboBox2.TabIndex = 8;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.SystemColors.ActiveCaption;
            this.label5.Location = new System.Drawing.Point(593, 54);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(58, 26);
            this.label5.TabIndex = 7;
            this.label5.Text = "Stele";
            // 
            // listBox1
            // 
            this.listBox1.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this.listBox1.FormattingEnabled = true;
            this.listBox1.ItemHeight = 22;
            this.listBox1.Location = new System.Drawing.Point(28, 344);
            this.listBox1.Name = "listBox1";
            this.listBox1.Size = new System.Drawing.Size(444, 180);
            this.listBox1.TabIndex = 6;
            // 
            // button4
            // 
            this.button4.Location = new System.Drawing.Point(277, 249);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(195, 47);
            this.button4.TabIndex = 5;
            this.button4.Text = "Statistici galaxie";
            this.button4.UseVisualStyleBackColor = true;
            this.button4.Click += new System.EventHandler(this.button4_Click);
            // 
            // button3
            // 
            this.button3.Location = new System.Drawing.Point(277, 175);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(195, 47);
            this.button3.TabIndex = 4;
            this.button3.Text = "Vezi planetele";
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // button2
            // 
            this.button2.ForeColor = System.Drawing.SystemColors.MenuText;
            this.button2.Location = new System.Drawing.Point(277, 95);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(195, 55);
            this.button2.TabIndex = 3;
            this.button2.Text = "Vezi stelele galaxiei selectate";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // comboBox1
            // 
            this.comboBox1.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this.comboBox1.FormattingEnabled = true;
            this.comboBox1.Items.AddRange(new object[] {
            "Calea Lactee",
            "Andromeda",
            "Triangulum",
            "M87",
            "Sombrero"});
            this.comboBox1.Location = new System.Drawing.Point(28, 153);
            this.comboBox1.Name = "comboBox1";
            this.comboBox1.Size = new System.Drawing.Size(166, 30);
            this.comboBox1.TabIndex = 2;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.SystemColors.ActiveCaption;
            this.label4.Location = new System.Drawing.Point(23, 124);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(82, 26);
            this.label4.TabIndex = 1;
            this.label4.Text = "Galaxii";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.BackColor = System.Drawing.Color.Transparent;
            this.label3.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label3.Font = new System.Drawing.Font("Castellar", 16.2F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.SystemColors.ActiveCaption;
            this.label3.Location = new System.Drawing.Point(22, 35);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(440, 34);
            this.label3.TabIndex = 0;
            this.label3.Text = "Calatorie astronomica";
            // 
            // TabEnciclopedieAstronomica
            // 
            this.TabEnciclopedieAstronomica.BackgroundImage = global::AtestatAnamariaC.Properties.Resources.background3;
            this.TabEnciclopedieAstronomica.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.TabEnciclopedieAstronomica.Controls.Add(this.dataGridView1);
            this.TabEnciclopedieAstronomica.Controls.Add(this.button9);
            this.TabEnciclopedieAstronomica.Controls.Add(this.button8);
            this.TabEnciclopedieAstronomica.Controls.Add(this.groupBox1);
            this.TabEnciclopedieAstronomica.Controls.Add(this.label6);
            this.TabEnciclopedieAstronomica.Location = new System.Drawing.Point(4, 31);
            this.TabEnciclopedieAstronomica.Name = "TabEnciclopedieAstronomica";
            this.TabEnciclopedieAstronomica.Padding = new System.Windows.Forms.Padding(3);
            this.TabEnciclopedieAstronomica.Size = new System.Drawing.Size(1064, 559);
            this.TabEnciclopedieAstronomica.TabIndex = 2;
            this.TabEnciclopedieAstronomica.Text = "Enciclopedie Astronomica";
            this.TabEnciclopedieAstronomica.UseVisualStyleBackColor = true;
            // 
            // dataGridView1
            // 
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Location = new System.Drawing.Point(540, 96);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.RowHeadersWidth = 51;
            this.dataGridView1.RowTemplate.Height = 24;
            this.dataGridView1.Size = new System.Drawing.Size(489, 258);
            this.dataGridView1.TabIndex = 5;
            this.dataGridView1.Visible = false;
            // 
            // button9
            // 
            this.button9.Location = new System.Drawing.Point(809, 479);
            this.button9.Name = "button9";
            this.button9.Size = new System.Drawing.Size(230, 56);
            this.button9.TabIndex = 4;
            this.button9.Text = "Clasamente Astronomice ----->";
            this.button9.UseVisualStyleBackColor = true;
            this.button9.Click += new System.EventHandler(this.button9_Click);
            // 
            // button8
            // 
            this.button8.Location = new System.Drawing.Point(29, 479);
            this.button8.Name = "button8";
            this.button8.Size = new System.Drawing.Size(235, 56);
            this.button8.TabIndex = 3;
            this.button8.Text = "Calatorie Astronomica <------";
            this.button8.UseVisualStyleBackColor = true;
            this.button8.Click += new System.EventHandler(this.button8_Click);
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.button17);
            this.groupBox1.Controls.Add(this.button16);
            this.groupBox1.Controls.Add(this.button7);
            this.groupBox1.ForeColor = System.Drawing.SystemColors.HighlightText;
            this.groupBox1.Location = new System.Drawing.Point(29, 100);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(459, 223);
            this.groupBox1.TabIndex = 1;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Planete";
            // 
            // button17
            // 
            this.button17.ForeColor = System.Drawing.SystemColors.ControlText;
            this.button17.Location = new System.Drawing.Point(32, 157);
            this.button17.Name = "button17";
            this.button17.Size = new System.Drawing.Size(187, 37);
            this.button17.TabIndex = 2;
            this.button17.Text = "Afiseaza Galaxiile";
            this.button17.UseVisualStyleBackColor = true;
            this.button17.Click += new System.EventHandler(this.button17_Click);
            // 
            // button16
            // 
            this.button16.ForeColor = System.Drawing.SystemColors.ControlText;
            this.button16.Location = new System.Drawing.Point(32, 97);
            this.button16.Name = "button16";
            this.button16.Size = new System.Drawing.Size(187, 37);
            this.button16.TabIndex = 1;
            this.button16.Text = "Afiseaza Stele";
            this.button16.UseVisualStyleBackColor = true;
            this.button16.Click += new System.EventHandler(this.button16_Click);
            // 
            // button7
            // 
            this.button7.ForeColor = System.Drawing.SystemColors.InactiveCaptionText;
            this.button7.Location = new System.Drawing.Point(32, 41);
            this.button7.Name = "button7";
            this.button7.Size = new System.Drawing.Size(187, 38);
            this.button7.TabIndex = 0;
            this.button7.Text = "Afiseaza planetele";
            this.button7.UseVisualStyleBackColor = true;
            this.button7.Click += new System.EventHandler(this.button7_Click);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Castellar", 16.2F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.ForeColor = System.Drawing.SystemColors.Window;
            this.label6.Location = new System.Drawing.Point(23, 34);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(484, 34);
            this.label6.TabIndex = 0;
            this.label6.Text = "Enciclopedie Astronomica";
            // 
            // TabClasamenteAstronomice
            // 
            this.TabClasamenteAstronomice.BackgroundImage = global::AtestatAnamariaC.Properties.Resources.download__2_;
            this.TabClasamenteAstronomice.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.TabClasamenteAstronomice.Controls.Add(this.listBox2);
            this.TabClasamenteAstronomice.Controls.Add(this.button15);
            this.TabClasamenteAstronomice.Controls.Add(this.button14);
            this.TabClasamenteAstronomice.Controls.Add(this.button13);
            this.TabClasamenteAstronomice.Controls.Add(this.button12);
            this.TabClasamenteAstronomice.Controls.Add(this.button11);
            this.TabClasamenteAstronomice.Controls.Add(this.button10);
            this.TabClasamenteAstronomice.Controls.Add(this.label7);
            this.TabClasamenteAstronomice.Controls.Add(this.pictureBox2);
            this.TabClasamenteAstronomice.Location = new System.Drawing.Point(4, 31);
            this.TabClasamenteAstronomice.Name = "TabClasamenteAstronomice";
            this.TabClasamenteAstronomice.Padding = new System.Windows.Forms.Padding(3);
            this.TabClasamenteAstronomice.Size = new System.Drawing.Size(1064, 559);
            this.TabClasamenteAstronomice.TabIndex = 3;
            this.TabClasamenteAstronomice.Text = "Clasamente Astronomice";
            this.TabClasamenteAstronomice.UseVisualStyleBackColor = true;
            // 
            // listBox2
            // 
            this.listBox2.BackColor = System.Drawing.SystemColors.GrayText;
            this.listBox2.ForeColor = System.Drawing.SystemColors.MenuText;
            this.listBox2.FormattingEnabled = true;
            this.listBox2.ItemHeight = 22;
            this.listBox2.Location = new System.Drawing.Point(567, 84);
            this.listBox2.Name = "listBox2";
            this.listBox2.Size = new System.Drawing.Size(369, 180);
            this.listBox2.TabIndex = 8;
            // 
            // button15
            // 
            this.button15.Location = new System.Drawing.Point(856, 488);
            this.button15.Name = "button15";
            this.button15.Size = new System.Drawing.Size(167, 36);
            this.button15.TabIndex = 6;
            this.button15.Text = "Iesire";
            this.button15.UseVisualStyleBackColor = true;
            this.button15.Click += new System.EventHandler(this.button15_Click);
            // 
            // button14
            // 
            this.button14.Location = new System.Drawing.Point(39, 478);
            this.button14.Name = "button14";
            this.button14.Size = new System.Drawing.Size(242, 56);
            this.button14.TabIndex = 5;
            this.button14.Text = "Enciclopedie Astronomica <-----";
            this.button14.UseVisualStyleBackColor = true;
            this.button14.Click += new System.EventHandler(this.button14_Click);
            // 
            // button13
            // 
            this.button13.Location = new System.Drawing.Point(39, 288);
            this.button13.Name = "button13";
            this.button13.Size = new System.Drawing.Size(308, 48);
            this.button13.TabIndex = 4;
            this.button13.Text = "Top constelatii dupa nr. de stele";
            this.button13.UseVisualStyleBackColor = true;
            this.button13.Click += new System.EventHandler(this.button13_Click);
            // 
            // button12
            // 
            this.button12.Location = new System.Drawing.Point(39, 223);
            this.button12.Name = "button12";
            this.button12.Size = new System.Drawing.Size(308, 40);
            this.button12.TabIndex = 3;
            this.button12.Text = "Top 5 cele mai batrane stele";
            this.button12.UseVisualStyleBackColor = true;
            this.button12.Click += new System.EventHandler(this.button12_Click);
            // 
            // button11
            // 
            this.button11.Location = new System.Drawing.Point(39, 157);
            this.button11.Name = "button11";
            this.button11.Size = new System.Drawing.Size(308, 40);
            this.button11.TabIndex = 2;
            this.button11.Text = "Top 5 planete cele mai indepartate";
            this.button11.UseVisualStyleBackColor = true;
            this.button11.Click += new System.EventHandler(this.button11_Click);
            // 
            // button10
            // 
            this.button10.Location = new System.Drawing.Point(39, 95);
            this.button10.Name = "button10";
            this.button10.Size = new System.Drawing.Size(308, 38);
            this.button10.TabIndex = 1;
            this.button10.Text = "Top 3 galaxii dupa diametru";
            this.button10.UseVisualStyleBackColor = true;
            this.button10.Click += new System.EventHandler(this.button10_Click);
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Castellar", 16.2F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.ForeColor = System.Drawing.SystemColors.HighlightText;
            this.label7.Location = new System.Drawing.Point(24, 35);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(482, 34);
            this.label7.TabIndex = 0;
            this.label7.Text = "Clasamanete Astronomice";
            // 
            // pictureBox2
            // 
            this.pictureBox2.BackgroundImage = global::AtestatAnamariaC.Properties.Resources.Clouds_of_Venus;
            this.pictureBox2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pictureBox2.Location = new System.Drawing.Point(17, 84);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(354, 288);
            this.pictureBox2.TabIndex = 7;
            this.pictureBox2.TabStop = false;
            // 
            // imageList1
            // 
            this.imageList1.ImageStream = ((System.Windows.Forms.ImageListStreamer)(resources.GetObject("imageList1.ImageStream")));
            this.imageList1.TransparentColor = System.Drawing.Color.Transparent;
            this.imageList1.Images.SetKeyName(0, "background.jpeg");
            // 
            // imageList2
            // 
            this.imageList2.ImageStream = ((System.Windows.Forms.ImageListStreamer)(resources.GetObject("imageList2.ImageStream")));
            this.imageList2.TransparentColor = System.Drawing.Color.Transparent;
            this.imageList2.Images.SetKeyName(0, "background2.jpeg");
            // 
            // planeteBindingSource
            // 
            this.planeteBindingSource.DataMember = "Planete";
            this.planeteBindingSource.DataSource = this.atestatDataSet;
            // 
            // atestatDataSet
            // 
            this.atestatDataSet.DataSetName = "atestatDataSet";
            this.atestatDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // constelatiiBindingSource
            // 
            this.constelatiiBindingSource.DataMember = "Constelatii";
            this.constelatiiBindingSource.DataSource = this.atestatDataSet;
            // 
            // constelatiiTableAdapter
            // 
            this.constelatiiTableAdapter.ClearBeforeFill = true;
            // 
            // tableAdapterManager
            // 
            this.tableAdapterManager.BackupDataSetBeforeUpdate = false;
            this.tableAdapterManager.ConstelatiiTableAdapter = this.constelatiiTableAdapter;
            this.tableAdapterManager.GalaxiiTableAdapter = this.galaxiiTableAdapter;
            this.tableAdapterManager.PlaneteTableAdapter = this.planeteTableAdapter;
            this.tableAdapterManager.SteleTableAdapter = this.steleTableAdapter;
            this.tableAdapterManager.UpdateOrder = AtestatAnamariaC.atestatDataSetTableAdapters.TableAdapterManager.UpdateOrderOption.InsertUpdateDelete;
            // 
            // galaxiiTableAdapter
            // 
            this.galaxiiTableAdapter.ClearBeforeFill = true;
            // 
            // planeteTableAdapter
            // 
            this.planeteTableAdapter.ClearBeforeFill = true;
            // 
            // steleTableAdapter
            // 
            this.steleTableAdapter.ClearBeforeFill = true;
            // 
            // galaxiiBindingSource
            // 
            this.galaxiiBindingSource.DataMember = "Galaxii";
            this.galaxiiBindingSource.DataSource = this.atestatDataSet;
            // 
            // steleBindingSource
            // 
            this.steleBindingSource.DataMember = "Stele";
            this.steleBindingSource.DataSource = this.atestatDataSet;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1072, 624);
            this.Controls.Add(this.menuStrip2);
            this.Controls.Add(this.tabControl1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.menuStrip2.ResumeLayout(false);
            this.menuStrip2.PerformLayout();
            this.tabControl1.ResumeLayout(false);
            this.Home.ResumeLayout(false);
            this.Home.PerformLayout();
            this.TabCalatorieAstronomica.ResumeLayout(false);
            this.TabCalatorieAstronomica.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.TabEnciclopedieAstronomica.ResumeLayout(false);
            this.TabEnciclopedieAstronomica.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.groupBox1.ResumeLayout(false);
            this.TabClasamenteAstronomice.ResumeLayout(false);
            this.TabClasamenteAstronomice.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.planeteBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.atestatDataSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.constelatiiBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.galaxiiBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.steleBindingSource)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private atestatDataSet atestatDataSet;
        private System.Windows.Forms.BindingSource constelatiiBindingSource;
        private atestatDataSetTableAdapters.ConstelatiiTableAdapter constelatiiTableAdapter;
        private atestatDataSetTableAdapters.TableAdapterManager tableAdapterManager;
        private atestatDataSetTableAdapters.GalaxiiTableAdapter galaxiiTableAdapter;
        private System.Windows.Forms.BindingSource galaxiiBindingSource;
        private atestatDataSetTableAdapters.PlaneteTableAdapter planeteTableAdapter;
        private System.Windows.Forms.BindingSource planeteBindingSource;
        private atestatDataSetTableAdapters.SteleTableAdapter steleTableAdapter;
        private System.Windows.Forms.BindingSource steleBindingSource;
        private System.Windows.Forms.MenuStrip menuStrip2;
        private System.Windows.Forms.ToolStripMenuItem homeToolStripMenuItem;
        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage Home;
        private System.Windows.Forms.TabPage TabCalatorieAstronomica;
        private System.Windows.Forms.TabPage TabEnciclopedieAstronomica;
        private System.Windows.Forms.TabPage TabClasamenteAstronomice;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.ComboBox comboBox1;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Button button5;
        private System.Windows.Forms.ComboBox comboBox2;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.ListBox listBox1;
        private System.Windows.Forms.Button button6;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Button button7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Button button9;
        private System.Windows.Forms.Button button8;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Button button11;
        private System.Windows.Forms.Button button10;
        private System.Windows.Forms.Button button15;
        private System.Windows.Forms.Button button14;
        private System.Windows.Forms.Button button13;
        private System.Windows.Forms.Button button12;
        private System.Windows.Forms.ImageList imageList1;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.ImageList imageList2;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.Button button17;
        private System.Windows.Forms.Button button16;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.ListBox listBox2;
    }
}

