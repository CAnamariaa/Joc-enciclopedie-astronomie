﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Windows.Forms.VisualStyles;

namespace AtestatAnamariaC
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void constelatiiBindingNavigatorSaveItem_Click(object sender, EventArgs e)
        {
            this.Validate();
            this.constelatiiBindingSource.EndEdit();
            this.tableAdapterManager.UpdateAll(this.atestatDataSet);

        }

        private void Form1_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'atestatDataSet.Stele' table. You can move, or remove it, as needed.
            this.steleTableAdapter.Fill(this.atestatDataSet.Stele);
            // TODO: This line of code loads data into the 'atestatDataSet.Planete' table. You can move, or remove it, as needed.
            this.planeteTableAdapter.Fill(this.atestatDataSet.Planete);
            // TODO: This line of code loads data into the 'atestatDataSet.Galaxii' table. You can move, or remove it, as needed.
            this.galaxiiTableAdapter.FillBy(this.atestatDataSet.Galaxii);
            // TODO: This line of code loads data into the 'atestatDataSet.Constelatii' table. You can move, or remove it, as needed.
            this.constelatiiTableAdapter.Fill(this.atestatDataSet.Constelatii);

        }

        private void constelatiiBindingNavigator_RefreshItems(object sender, EventArgs e)
        {

        }

        private void menuStrip2_ItemClicked(object sender, ToolStripItemClickedEventArgs e)
        {

        }

        private void button11_Click(object sender, EventArgs e)
        {
           
            listBox2.Items.Clear();  

            try
            {
                using (SqlConnection conn = new SqlConnection(planeteTableAdapter.Connection.ConnectionString))
                {
                    string query = @"
            SELECT TOP 5 Nume_planeta, Distanta_soare
            FROM Planete
            ORDER BY Distanta_soare DESC";  

                    using (SqlCommand cmd = new SqlCommand(query, conn))
                    {
                        conn.Open();
                        using (SqlDataReader reader = cmd.ExecuteReader())
                        {
                            if (!reader.HasRows) 
                            {
                                MessageBox.Show("Nu au fost găsite planete.");
                            }

                            int rank = 1;
                            while (reader.Read())
                            {
                                string nume = reader["Nume_planeta"].ToString();
                                string distanta = reader["Distanta_soare"].ToString();
                                listBox2.Items.Add($"{rank}. {nume} - {distanta} ani lumină");
                                rank++;
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Eroare la încărcarea planetelor: " + ex.Message, "Eroare",
                                MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        

        private void Home_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            tabControl1.SelectedTab = TabCalatorieAstronomica;

        }

        private void button6_Click(object sender, EventArgs e)
        {
            tabControl1.SelectedTab = TabEnciclopedieAstronomica;

        }

        private void button8_Click(object sender, EventArgs e)
        {
            tabControl1.SelectedTab = TabCalatorieAstronomica;

        }

        private void button9_Click(object sender, EventArgs e)
        {
            tabControl1.SelectedTab = TabClasamenteAstronomice;

        }

        private void button14_Click(object sender, EventArgs e)
        {
            tabControl1.SelectedTab = TabEnciclopedieAstronomica;

        }

        private void button15_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }



        private void button2_Click(object sender, EventArgs e)
        {

            if (comboBox1.SelectedIndex == -1)
            {
                MessageBox.Show("Vă rugăm să selectați o galaxie din listă.", "Atenție",
                               MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            try
            {

                listBox1.Items.Clear();
                string selectedGalaxy = comboBox1.SelectedItem.ToString();

                using (System.Data.SqlClient.SqlConnection connection = new System.Data.SqlClient.SqlConnection(steleTableAdapter.Connection.ConnectionString))
                {
                    string query = @"SELECT S.Nume_stea
                           FROM Stele AS S INNER JOIN
                           Galaxii AS G ON S.Idg = G.Idg
                           WHERE (G.Nume_galaxie = @galaxii)";

                    using (System.Data.SqlClient.SqlCommand command = new System.Data.SqlClient.SqlCommand(query, connection))
                    {
                        command.Parameters.AddWithValue("@galaxii", selectedGalaxy);

                        connection.Open();

                        using (System.Data.SqlClient.SqlDataReader reader = command.ExecuteReader())
                        {
                            bool hasResults = false;

                            while (reader.Read())
                            {
                                listBox1.Items.Add(reader["Nume_stea"].ToString());
                                hasResults = true;
                            }

                            if (!hasResults)
                            {
                                listBox1.Items.Add("Nu s-au găsit stele în galaxia selectată.");
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Eroare la încărcarea stelelor: " + ex.Message, "Eroare",
                                MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {

            if (comboBox1.SelectedIndex == -1)
            {
                MessageBox.Show("Vă rugăm să selectați o galaxie din listă.", "Atenție",
                               MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            try
            {

                listBox1.Items.Clear();


                string selectedGalaxy = comboBox1.SelectedItem.ToString();


                using (System.Data.SqlClient.SqlConnection connection = new System.Data.SqlClient.SqlConnection(planeteTableAdapter.Connection.ConnectionString))
                {

                    string query = @"SELECT P.Nume_planeta
                         FROM Planete AS P 
                         INNER JOIN Galaxii AS G ON P.Idg = G.Idg
                         WHERE G.Nume_galaxie = @galaxie";

                    using (System.Data.SqlClient.SqlCommand command = new System.Data.SqlClient.SqlCommand(query, connection))
                    {
                        command.Parameters.AddWithValue("@galaxie", selectedGalaxy);

                        connection.Open();

                        using (System.Data.SqlClient.SqlDataReader reader = command.ExecuteReader())
                        {

                            bool hasResults = false;

                            while (reader.Read())
                            {
                                listBox1.Items.Add(reader["Nume_planeta"].ToString());
                                hasResults = true;
                            }


                            if (!hasResults)
                            {
                                listBox1.Items.Add("Nu s-au găsit planete în galaxia selectată.");
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                listBox1.Items.Clear();
                MessageBox.Show("Eroare la încărcarea planetelor: " + ex.Message, "Eroare",
                                MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void button4_Click(object sender, EventArgs e)
        {

            if (comboBox1.SelectedIndex == -1)
            {
                MessageBox.Show("Selectați o galaxie pentru a vedea statisticile.", "Atenție",
                                MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            string selectedGalaxy = comboBox1.SelectedItem.ToString();


            listBox1.Items.Clear();

            using (SqlConnection connection = new SqlConnection(planeteTableAdapter.Connection.ConnectionString))
            {
                try
                {
                    connection.Open();


                    string queryPlanete = @"SELECT COUNT(*) FROM Planete P 
                                    INNER JOIN Galaxii G ON P.Idg = G.Idg
                                    WHERE G.Nume_galaxie = @galaxie";


                    string queryStele = @"SELECT COUNT(*) FROM Stele S 
                                  INNER JOIN Galaxii G ON S.Idg = G.Idg
                                  WHERE G.Nume_galaxie = @galaxie";

                    int nrPlanete = 0;
                    int nrStele = 0;

                    using (SqlCommand cmdPlanete = new SqlCommand(queryPlanete, connection))
                    {
                        cmdPlanete.Parameters.AddWithValue("@galaxie", selectedGalaxy);
                        nrPlanete = (int)cmdPlanete.ExecuteScalar();
                    }

                    using (SqlCommand cmdStele = new SqlCommand(queryStele, connection))
                    {
                        cmdStele.Parameters.AddWithValue("@galaxie", selectedGalaxy);
                        nrStele = (int)cmdStele.ExecuteScalar();
                    }


                    listBox1.Items.Add($"Statistici pentru galaxia: {selectedGalaxy}");
                    listBox1.Items.Add($"• Număr de planete: {nrPlanete}");
                    listBox1.Items.Add($"• Număr de stele: {nrStele}");
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Eroare la încărcarea statisticilor: " + ex.Message,
                                    "Eroare", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        private void button5_Click(object sender, EventArgs e)
        {

            if (comboBox2.SelectedIndex == -1)
            {
                MessageBox.Show("Selectați o stea pentru a-i vedea constelația.", "Atenție",
                                MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            string numeStea = comboBox2.SelectedItem.ToString();

            using (SqlConnection connection = new SqlConnection(steleTableAdapter.Connection.ConnectionString))
            {
                try
                {
                    connection.Open();

                    string query = @"SELECT C.Nume_constelatie
                             FROM Stele S
                             INNER JOIN Constelatii C ON S.IdC = C.IdC
                             WHERE S.Nume_stea = @numeStea";

                    using (SqlCommand command = new SqlCommand(query, connection))
                    {
                        command.Parameters.AddWithValue("@numeStea", numeStea);

                        object rezultat = command.ExecuteScalar();

                        if (rezultat != null)
                        {
                            textBox1.Text = rezultat.ToString();
                        }
                        else
                        {
                            textBox1.Text = "Nu s-a găsit constelația.";
                        }
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Eroare la interogare: " + ex.Message, "Eroare",
                                    MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }
        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            dataGridView1.Visible = false;

        }
        private void button7_Click(object sender, EventArgs e)
        {

            try
            {
                using (SqlConnection connection = new SqlConnection(planeteTableAdapter.Connection.ConnectionString))
                {
                    connection.Open();
                    dataGridView1.Visible = true;

                    string query = "SELECT * FROM Planete"; 

                    using (SqlCommand command = new SqlCommand(query, connection))
                    {
                        SqlDataAdapter adapter = new SqlDataAdapter(command);
                        DataTable dt = new DataTable();
                        adapter.Fill(dt);

                        dataGridView1.DataSource = dt; 
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Eroare la afișarea tabelului: " + ex.Message, "Eroare",
                                MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void button16_Click(object sender, EventArgs e)
        {

            using (SqlConnection conn = new SqlConnection(steleTableAdapter.Connection.ConnectionString))
            {
                SqlDataAdapter adapter = new SqlDataAdapter("SELECT * FROM Stele", conn);
                DataTable table = new DataTable();
                adapter.Fill(table);
                dataGridView1.DataSource = table;
                dataGridView1.Visible = true;
            }
        }

        private void button17_Click(object sender, EventArgs e)
        {
            using (SqlConnection conn = new SqlConnection(steleTableAdapter.Connection.ConnectionString))
            {
                SqlDataAdapter adapter = new SqlDataAdapter("SELECT * FROM Galaxii", conn);
                DataTable table = new DataTable();
                adapter.Fill(table);
                dataGridView1.DataSource = table;
                dataGridView1.Visible = true;
            }
        }

        private void button10_Click(object sender, EventArgs e)
        {
            listBox2.Items.Clear();
            try
            {
                using (SqlConnection conn = new SqlConnection(galaxiiTableAdapter.Connection.ConnectionString))
                {
                    string query = @"
            SELECT TOP 3 Nume_galaxie, Diametru_galaxie
            FROM Galaxii
            ORDER BY Diametru_galaxie DESC";

                    using (SqlCommand cmd = new SqlCommand(query, conn))
                    {
                        conn.Open();
                        using (SqlDataReader reader = cmd.ExecuteReader())
                        {
                            if (!reader.HasRows) 
                            {
                                MessageBox.Show("Nu au fost găsite galaxiile.");
                            }

                            int rank = 1;
                            while (reader.Read())
                            {
                                string nume = reader["Nume_galaxie"].ToString();
                                string diametru = reader["Diametru_galaxie"].ToString();
                                listBox2.Items.Add($"{rank}. {nume} - {diametru} ani lumină");
                                rank++;
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Eroare la încărcarea galaxiilor: " + ex.Message, "Eroare",
                                MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void button12_Click(object sender, EventArgs e)
        {
           
            listBox2.Items.Clear();  

            try
            {
                using (SqlConnection conn = new SqlConnection(steleTableAdapter.Connection.ConnectionString))
                {
                    string query = @"
            SELECT TOP 5 Nume_stea, Varsta
            FROM Stele
            ORDER BY Varsta DESC";  

                    using (SqlCommand cmd = new SqlCommand(query, conn))
                    {
                        conn.Open();
                        using (SqlDataReader reader = cmd.ExecuteReader())
                        {
                            if (!reader.HasRows) 
                            {
                                MessageBox.Show("Nu au fost găsite stele.");
                            }

                            int rank = 1;
                            while (reader.Read())
                            {
                                string nume = reader["Nume_stea"].ToString();
                                string varsta = reader["Varsta"].ToString();
                                listBox2.Items.Add($"{rank}. {nume} - {varsta} ani");
                                rank++;
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Eroare la încărcarea stelelor: " + ex.Message, "Eroare",
                                MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void button13_Click(object sender, EventArgs e)
        {
           
            listBox2.Items.Clear();  

            try
            {
                using (SqlConnection conn = new SqlConnection(constelatiiTableAdapter.Connection.ConnectionString))
                {
                    string query = @"
            SELECT TOP 5 C.Nume_constelatie, COUNT(S.IdS) AS Nr_stele
            FROM Stele AS S
            INNER JOIN Constelatii AS C ON S.IdC = C.IdC
            GROUP BY C.Nume_constelatie
            ORDER BY Nr_stele DESC"; 

                    using (SqlCommand cmd = new SqlCommand(query, conn))
                    {
                        conn.Open();
                        using (SqlDataReader reader = cmd.ExecuteReader())
                        {
                            if (!reader.HasRows) 
                            {
                                MessageBox.Show("Nu au fost găsite constelații.");
                            }

                            int rank = 1;
                            while (reader.Read())
                            {
                                string nume = reader["Nume_constelatie"].ToString();
                                string nrStele = reader["Nr_stele"].ToString();
                                listBox2.Items.Add($"{rank}. {nume} - {nrStele} stele");
                                rank++;
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Eroare la încărcarea constelațiilor: " + ex.Message, "Eroare",
                                MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void homeToolStripMenuItem_Click(object sender, EventArgs e)
        {
            tabControl1.SelectedTab = tabControl1.TabPages["Home"];
        }
    }
}



    




    

