﻿using System;
using System.Data;

namespace AtestatAnamariaC
{


    partial class atestatDataSet
    {
    }
}

namespace AtestatAnamariaC.atestatDataSetTableAdapters {


    public partial class SteleTableAdapter
    {
        internal DataTable steleleDinGalaxie(string selectedGalaxy)
        {
            throw new NotImplementedException();
        }
    }
}
